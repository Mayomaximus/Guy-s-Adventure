var PlayScreen = me.ScreenObject.extend
({
  onDestroyEvent: function()
  {
  	me.gamestat.reset("coins");
  },
  onResetEvent: function() 
  {
  	//var numCoin = (me.gamestat.getItemValue("totalCoins")) - (me.gamestat.getItemValue("coins"));
    me.levelDirector.loadLevel("level1");
    me.input.bindKey(me.input.KEY.LEFT, "left");
    me.input.bindKey(me.input.KEY.RIGHT, "right");
    document.getElementById('game_state').innerHTML = "Collect 10 coins!";
    document.getElementById('instructions').innerHTML = "Arrows to move and Space to jump.";
    document.getElementById('condition').innerHTML = "Block Monsters Will Eat One of Your Coins And Vanish";
  }
});

var TitleScreen = me.ScreenObject.extend
({
	init: function()
	{
		this.parent(true);
		me.input.bindKey(me.input.KEY.SPACE, "jump", true);
	},
	onResetEvent: function()
	{
			this.title = me.loader.getImage("TitleScreen");
			document.getElementById('game_state').innerHTML = "";
			document.getElementById('instructions').innerHTML = "";
	},
	update: function()
	{
		if (me.input.isKeyPressed('jump'))
		{
			me.state.change(me.state.PLAY);
		}
		return true;
	},
	draw: function(context)
	{
		context.drawImage(this.title, 50, 50);
	}
});
